import React from "react";

const ColorPalette = () => {
  const colors = [
    { name: "Primary", color: "#1E3A8A" },
    { name: "Secondary", color: "#F43F5E" },
    { name: "Accent", color: "#10B981" },
    { name: "Neutral", color: "#111827" },
  ];

  return (
    <section className="my-8 p-4">
      <h2 className="text-3xl font-bold mb-4">Color Palette</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {colors.map((c) => (
          <div
            key={c.name}
            className="p-4 border rounded-lg text-center"
            style={{ backgroundColor: c.color, color: "#fff" }}
          >
            <p className="font-bold">{c.name}</p>
            <p>{c.color}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ColorPalette;
