import React from "react";

const StyleGuide = () => {
  return (
    <section className="my-8 p-4">
      <h2 className="text-3xl font-bold mb-4">Style Guide</h2>
      <p className="text-lg">
        This section demonstrates the font styles, headings, and text layout defined in the design.
      </p>
      <div className="my-4">
        <h1 className="text-6xl font-bold mb-2">Heading H1</h1>
        <h2 className="text-5xl font-bold mb-2">Heading H2</h2>
        <h3 className="text-4xl font-bold mb-2">Heading H3</h3>
      </div>
    </section>
  );
};

export default StyleGuide;
