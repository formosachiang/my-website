import React from "react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import StyleGuide from "./components/StyleGuide";
import ColorPalette from "./components/ColorPalette";

function App() {
  return (
    <div className="App">
      <Header />
      <main className="container mx-auto my-8">
        <StyleGuide />
        <ColorPalette />
      </main>
      <Footer />
    </div>
  );
}

export default App;
